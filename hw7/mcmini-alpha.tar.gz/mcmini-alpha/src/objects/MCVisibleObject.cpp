#include "mcmini/objects/MCVisibleObject.h"

objid_t
MCVisibleObject::getObjectId() const
{
  return this->id;
}
