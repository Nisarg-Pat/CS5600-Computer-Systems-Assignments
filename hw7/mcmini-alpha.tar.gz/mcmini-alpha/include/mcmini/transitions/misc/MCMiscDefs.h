#ifndef GMAL_GMALMISCDEFS_H
#define GMAL_GMALMISCDEFS_H

#include "mcmini/transitions/misc/MCAbortTransition.h"
#include "mcmini/transitions/misc/MCExitTransition.h"
#include "mcmini/transitions/misc/MCGlobalVariableRead.h"
#include "mcmini/transitions/misc/MCGlobalVariableWrite.h"

#endif // GMAL_GMALMISCDEFS_H
