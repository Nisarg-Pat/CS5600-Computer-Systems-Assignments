#ifndef MC_MCCONDDEFS_H
#define MC_MCCONDDEFS_H

#include "mcmini/transitions/cond/MCCondBroadcast.h"
#include "mcmini/transitions/cond/MCCondEnqueue.h"
#include "mcmini/transitions/cond/MCCondInit.h"
#include "mcmini/transitions/cond/MCCondSignal.h"
#include "mcmini/transitions/cond/MCCondWait.h"

#endif // MC_MCCONDDEFS_H
