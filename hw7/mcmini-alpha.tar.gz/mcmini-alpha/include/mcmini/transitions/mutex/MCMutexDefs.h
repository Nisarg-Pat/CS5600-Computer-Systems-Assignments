#ifndef MC_MCMUTEXDEFS_H
#define MC_MCMUTEXDEFS_H

#include "mcmini/transitions/mutex/MCMutexInit.h"
#include "mcmini/transitions/mutex/MCMutexLock.h"
#include "mcmini/transitions/mutex/MCMutexUnlock.h"

#endif // MC_MCMUTEXDEFS_H
