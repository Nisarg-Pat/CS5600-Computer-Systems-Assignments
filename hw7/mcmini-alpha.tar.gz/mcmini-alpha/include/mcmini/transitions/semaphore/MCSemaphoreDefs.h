#ifndef MC_MCSEMAPHOREDEFS_H
#define MC_MCSEMAPHOREDEFS_H

#include "mcmini/transitions/semaphore/MCSemEnqueue.h"
#include "mcmini/transitions/semaphore/MCSemInit.h"
#include "mcmini/transitions/semaphore/MCSemPost.h"
#include "mcmini/transitions/semaphore/MCSemWait.h"

#endif // MC_MCSEMAPHOREDEFS_H
