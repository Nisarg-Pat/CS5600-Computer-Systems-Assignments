#ifndef MC_MCTHREADDEFS_H
#define MC_MCTHREADDEFS_H

#include "mcmini/transitions/threads/MCThreadCreate.h"
#include "mcmini/transitions/threads/MCThreadFinish.h"
#include "mcmini/transitions/threads/MCThreadJoin.h"
#include "mcmini/transitions/threads/MCThreadStart.h"

#endif // MC_MCTHREADDEFS_H
