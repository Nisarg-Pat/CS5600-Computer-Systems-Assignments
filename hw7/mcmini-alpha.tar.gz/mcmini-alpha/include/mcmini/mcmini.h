#ifndef INCLUDE_MCMINI_MCMINI_HPP
#define INCLUDE_MCMINI_MCMINI_HPP

#include "mcmini/MCShared.h"
#include "mcmini/mcmini_wrappers.h"

MC_CTOR void mcmini_main();
#endif // INCLUDE_MCMINI_MCMINI_HPP
