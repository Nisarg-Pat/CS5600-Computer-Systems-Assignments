#!/usr/bin/env zsh

cmake --build build --target install
