#!/bin/zsh

[ -d "./build" ] && rm -r ./build
